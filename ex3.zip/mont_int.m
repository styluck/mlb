function [outp,i]  = mont_int(f,x_min,x_max,N)     %%输入(a,b)积分区域，g为t的匿名函数,q实验次数
%%蒙特卡罗方法计算定积分（随机投点法）
%%k累计数、x随机点、y随机点代表一组随机点(x(i)，y(i)),z为转化后的被积函数

if nargin < 4 || isempty(N)
    N = 1e6;
end

Rnd = rand(N,2);

xx = x_min:0.01:x_max;%%生成随机数x，y组成(x(i)，y(i))
x = x_min + (x_max-x_min)*Rnd(:,1); %%积分区域与（0,1）区间线性转换
y_min = min(f(xx)); y_max = max(f(xx));%%得出被积函数在积分区域的上下限
y = y_min + (y_max-y_min)*Rnd(:,2); %%积分区域与（0,1）区间线性转换
i = y < f(x); %%累计y小于积分函数的次数
outp = sum(i)/N*(x_max-x_min)*(y_max-y_min) + y_min*(x_max-x_min);%%卡蒙特罗实验结果逆向推理，根据积分性质得到积分值

% 画图
figure
plot(x,y,'go',x(i),y(i),'bo')
axis([x_min x_max y_min y_max])
hold on
plot(xx,f(xx),'r-','LineWidth',2)
