%monte Carlo方法求积分
% f = @(x) sin(x);%x.^3 - x.^2;
f = @(x) x.^3 + .5*x.^2 + 5*x; x_min = 2; x_max = 3;
% f = @(x) cos(5*x); x_min = 0; x_max = pi;
% f = @(x) 1./x; x_min = 0.0001; x_max = 1;
% f = @(x) log(x); x_min = 1; x_max = 5;

J = mont_int(f,x_min,x_max);
% J = mont_int_avg(f,x_min,x_max);

p = integral(f, x_min,x_max);

fprintf('Real result: %2.4f, Simulated result: %2.4f\n',...
    p, J)