function J = mont_int_avg(f, x_min, x_max, N)
% f 为所求的积分函数，
% x_min：积分下界
% x_max：积分上界
if nargin < 4 || isempty(N)
    N = 1e6;
end

Range = x_max - x_min; % 函数f的定义域大小
x = rand(N, 1)*Range + x_min; %生成x的随机数，均匀分布

sum_avg = 0;
for i = 1:N
    
    area_i = f(x(i))*Range; % 计算每个长方形的面积
    sum_avg = sum_avg + area_i;

end

J = sum_avg/N;

